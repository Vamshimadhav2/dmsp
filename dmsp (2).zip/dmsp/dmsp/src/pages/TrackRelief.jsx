import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './TrackRelief.css';

function TrackRelief() {
  const [resources, setResources] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/resources')
      .then(response => setResources(response.data))
      .catch(error => console.error('Error fetching resources:', error));
  }, []);

  return (
    <div className="resources">
      <h2>Track Relief Resources</h2>
      {resources.length === 0 ? (
        <p>No resources available.</p>
      ) : (
        <ul>
          {resources.map((resource) => (
            <li key={resource.id}>
              <h3>{resource.name}</h3>
              <p><strong>Type:</strong> {resource.type}</p>
              <p><strong>Quantity:</strong> {resource.quantity}</p>
              <p><strong>Location:</strong> {resource.location}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default TrackRelief;
