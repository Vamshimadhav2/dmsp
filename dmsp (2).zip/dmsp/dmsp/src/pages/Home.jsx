// src/pages/Home.jsx
import React from 'react';
import './Home.css';
import floodImg from '../assets/flood.jpg';
import fireImg from '../assets/fire.jpg';
import earthquakeImg from '../assets/earthquake.jpg';
import cycloneImg from '../assets/cyclone.jpg';

function Home() {
  return (
    <div className="home-container">

      {/* Emergency Alert Banner */}
      <div className="emergency-alert">
        🚨 Emergency Alert: Stay safe during disasters. Follow official guidelines. 🔔
      </div>

      {/* Hero Section */}
      <div className="home-hero">
        <h1>🚨 Disaster Management System 🛡️</h1>
        <p>Empowering communities with rapid response & real-time coordination.</p>
        <div className="home-buttons">
          <a href="/report" className="home-btn">📝 Report Incident</a>
          <a href="/resources" className="home-btn outline">📦 Allocate Resources</a>
        </div>
      </div>

      {/* Image Gallery */}
      <div className="home-gallery">
        <div className="gallery-item">
          <img src={floodImg} alt="Flood" />
          <span className="caption">🌊Flood</span>
        </div>
        <div className="gallery-item">
          <img src={fireImg} alt="Fire" />
          <span className="caption">🌋Volcano Erruption</span>
        </div>
        <div className="gallery-item">
          <img src={earthquakeImg} alt="Earthquake" />
          <span className="caption">🌍Earthquake</span>
        </div>
        <div className="gallery-item">
          <img src={cycloneImg} alt="Cyclone" />
          <span className="caption">🌀Cyclone</span>
        </div>
      </div>

      {/* Emergency Contacts */}
      <div className="home-contacts">
        <h2>📞 Emergency Helpline</h2>
        <div className="contact-grid">
          <div className="contact-card">👮‍♂️ Police: <strong>100</strong></div>
          <div className="contact-card">🚑 Ambulance: <strong>102</strong></div>
          <div className="contact-card">🔥🚒 Fire: <strong>101</strong></div>
          <div className="contact-card">🆘 Disaster Helpline: <strong>108</strong></div>
          <div className="contact-card">📱 WhatsApp: <strong>+91-XXXXXXXXXX</strong></div>
        </div>
      </div>

      {/* Footer */}
      <footer style={{ marginTop: '2rem', textAlign: 'center', color: '#555' }}>
        © 2025 Disaster Response Team | Stay Safe 🌍
      </footer>
    </div>
  );
}

export default Home;
