import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ViewIncidents.css';

function ViewIncidents() {
  const [incidents, setIncidents] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/incidents')
      .then(response => setIncidents(response.data))
      .catch(error => console.error('Error fetching incidents:', error));
  }, []);

  return (
    <div className="incidents">
      <h2>Reported Incidents</h2>
      {incidents.length === 0 ? (
        <p>No incidents reported yet.</p>
      ) : (
        <ul>
          {incidents.map((incident) => (
            <li key={incident.id}>
              <h3>{incident.title}</h3>
              <p><strong>Location:</strong> {incident.location}</p>
              <p>{incident.description}</p>
              <p><em>{new Date(incident.timestamp).toLocaleString()}</em></p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ViewIncidents;
