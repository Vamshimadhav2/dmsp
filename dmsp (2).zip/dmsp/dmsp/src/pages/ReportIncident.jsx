import React, { useState } from 'react';
import axios from 'axios';
import './ReportIncident.css';

function ReportIncident() {
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title || !location || !description) {
      setMessage('All fields are required.');
      return;
    }

    setLoading(true);
    setMessage('');

    try {
      await axios.post('http://localhost:8080/api/incidents', {
        title,
        location,
        description,
      });
      setMessage('✅ Incident reported successfully!');
      setTitle('');
      setLocation('');
      setDescription('');
    } catch (error) {
      setMessage('❌ Error reporting incident. Try again.');
      console.error('API Error:', error.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="report">
      <h2>Report an Incident</h2>
      {message && <p className="message">{message}</p>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Incident Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          required
        />
        <textarea
          placeholder="Describe the incident"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit'}
        </button>
      </form>
    </div>
  );
}

export default ReportIncident;
