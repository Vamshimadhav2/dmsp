import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import ReportIncident from './pages/ReportIncident';
import TrackRelief from './pages/TrackRelief';
import ResourceAllocation from './pages/ResourceAllocation';
import './App.css';

function App() {
  return (
    <div className="app-container dark-theme">
      <Router>
        <Navigation />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/report" element={<ReportIncident />} />
            <Route path="/track" element={<TrackRelief />} />
            <Route path="/resources" element={<ResourceAllocation />} />
          </Routes>
        </main>
      </Router>
    </div>
  );
}

export default App;
